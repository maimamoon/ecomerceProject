<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\cpanel\EditorController;
use App\Http\Controllers\cpanel\CategoryController;
use App\Http\Controllers\cpanel\NewsController;
use App\Http\Controllers\cpanel\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// cpanel routes
Route::prefix('cpanel')->group(function () {
    // Editor Routes
	Route::controller(EditorController::class)->group(function () {
		// create pages 
		Route::get('editor/create', 'create');
		Route::post('editor/store', 'store');
		// get all  routes
		Route::get('editor/all', 'all');
		// show info 
		Route::get('editor/{id}/show', 'show')->where('id', '[0-9]+');	
		// update
		Route::patch('editor/{id}/update', 'update')->where('id', '[0-9]+');
		// delete
		Route::delete('editor/{id}/delete', 'delete')->where('id', '[0-9]+');
	});
	// Category Routes
	Route::controller(CategoryController::class)->group(function () {
		// create pages 
		Route::get('category/create', 'create');
		Route::post('category/store', 'store');
		// get all  routes
		Route::get('category/all', 'all');
		// show info 
		Route::get('category/{id}/show', 'show')->where('id', '[0-9]+');	
		// update
		Route::patch('category/{id}/update', 'update')->where('id', '[0-9]+');
		// delete
		Route::delete('category/{id}/delete', 'delete')->where('id', '[0-9]+');
	});
	// News Routes
	Route::controller(NewsController::class)->group(function () {
		// create pages 
		Route::get('news/create', 'create');
		Route::post('news/store', 'store');
		// get all  routes
		Route::get('news/all', 'all');
		// show info 
		Route::get('news/{id}/show', 'show')->where('id', '[0-9]+');	
		// update
		Route::patch('news/{id}/update', 'update')->where('id', '[0-9]+');
		// delete
		Route::delete('news/{id}/delete', 'delete')->where('id', '[0-9]+');
	});
	// HomeController Routes
	Route::controller(HomeController::class)->group(function () { 
		Route::get('home/index', 'index');
	});
});


