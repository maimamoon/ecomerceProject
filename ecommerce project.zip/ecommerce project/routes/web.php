<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\front\PageController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// front Routes
Route::controller(PageController::class)->group(function () {
	// create pages 
	Route::get('home', 'index');
	// show category info 
	Route::get('category/{id}/show', 'category')->where('id', '[0-9]+');
	// show news info 
	Route::get('news/{id}/show', 'news')->where('id', '[0-9]+');	
		
});
Route::get('/sh', function () {
    return view('shop');
});


