//landing page selector
let landingPage = document.getElementById("landing");
//Get Array of images
let imgsArray = ["imag5.avif","img-background2.jpg","img-backgrong3.jpg"];
setInterval(() => {
    //get random number
    let randomNumber= Math.floor(Math.random() * imgsArray.length );
    //change backgrond image url
    landingPage.style.backgroundImage = 'url("image/'+ imgsArray[randomNumber] +'")';
    
}, 4000);

