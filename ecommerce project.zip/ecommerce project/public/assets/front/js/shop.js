let iconCart = decument.querySelector('.icon-cart');
let body = decument.querySelector('body');

iconCart.addEventListener('click', () => {
  body.classList.toggle('showCart')
})
