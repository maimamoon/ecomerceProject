@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>Statstics</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<table>
    <tr>
        <th>Item</th>
        <th>Value</th>
    </tr>
    <tr>
        <td>Number of editors</td>
        <td>{{$noOfAllEditors}}</td>
    </tr>
    <tr>
        <td>Number of categories</td>
        <td>{{$noOfAllCategories}}</td>
    </tr>
    <tr>
        <td>Number of products</td>
        <td>{{$noOfAllNews}}</td>
    </tr>
</table>
@endSection