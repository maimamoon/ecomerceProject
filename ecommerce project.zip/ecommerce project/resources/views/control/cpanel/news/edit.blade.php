@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>show news info</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/news/$news->id/update")}}" method="post" enctype="multipart/form-data">
    @csrf
    @method('patch')
    <label>News title</label>
    <input type="text" name="title" value="{{$news->title}}"/>
    <label>News content</label>
    <textarea name="content">
        {{$news->content}}
    </textarea>
    <label>written By</label>
    <select name="id_editor">
        @if(!$allEditors->isEmpty())
            @foreach($allEditors as $editor)
                @if($editor->id == $news->id_editor)
                    <option selected="selected" value="{{$editor->id}}">{{$editor->name}}</a>
                @else
                    <option value="{{$editor->id}}">{{$editor->name}}</a>
                @endif
            @endforeach
        @else
            <option value="">no editor found</a>
        @endif
    </select>
    <label>belong to</label>
    <select name="id_category">
        @if(!$allCategories->isEmpty())
            @foreach($allCategories as $category)
                @if($category->id == $news->id_category)
                    <option selected="selected" value="{{$category->id}}">{{$category->name}}</a>
                @else
                    <option value="{{$category->id}}">{{$category->name}}</a>
                @endif
            @endforeach
        @else
            <option value="">no category found</a>
        @endif
    </select>
    <label>main image</label>
    <img src="{{asset("assets/upload/$news->main_image")}}" width="90" height="90" />
    <input type="file" name="main_image" />
    <input type="submit" name="updateNews" value="update news" />
</form>
@endSection