@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>Add new Product</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/news/store")}}" method="post" enctype="multipart/form-data">
    @csrf
    <label>Product Name</label>
    <input type="text" name="title" />
    <label>News content</label>
    <textarea name="content">
    </textarea>
    <label>written By</label>
    <select name="id_editor">
        @if(!$allEditors->isEmpty())
            @foreach($allEditors as $editor)
                <option value="{{$editor->id}}">{{$editor->name}}</a>
            @endforeach
        @else
            <option value="">no editor found</a>
        @endif
    </select>
    <label>belong to</label>
    <select name="id_category">
        @if(!$allCategories->isEmpty())
            @foreach($allCategories as $category)
                <option value="{{$category->id}}">{{$category->name}}</a>
            @endforeach
        @else
            <option value="">no category found</a>
        @endif
    </select>
    <label>main image</label>
    <input type="file" name="main_image" />
    <input type="submit" name="addNews" value="add new product" />
</form>
@endSection