@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>show all news</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<table>
    <tr>
        <th>ID</th>
        <th>title</th>
        <th>delete</th>
        <th>edit</th>
    </tr>
    @if(!$allNews->isEmpty())
        @foreach($allNews as $news)
            <tr>
                <td>{{$news->id}}</td>
                <td>{{$news->title}}</td>
                <td>
                    <form action="{{url("cpanel/news/$news->id/delete")}}" method='post'>
                        @csrf
                        @method('delete')
                        <input type='submit' name='deleteNews' value='delete' />
                    </form>
                </td>
                <td><a href="{{url("cpanel/news/$news->id/show")}}">edit</a></td>
            </tr>
        @endforeach
    @else
        <tr>
            <td colspan="4">no category found</td>
        </tr>
    @endif
</table>
@endSection