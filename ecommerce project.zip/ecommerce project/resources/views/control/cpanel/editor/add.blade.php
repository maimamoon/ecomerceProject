@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>Add new editor</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/editor/store")}}" method="post">
    @csrf
    <label>Editor name</label>
    <input type="text" name="name" />
    <label>Editor salary</label>
    <input type="text" name="salary" />
    <input type="submit" name="addEditor" value="add new editor" />
</form>
@endSection