@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>show all editors</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<table>
    <tr>
            <th>ID</th>
            <th>name</th>
            <th>delete</th>
            <th>edit</th>
    </tr>
    @if(!$allEditors->isEmpty())
        @foreach($allEditors as $editor)
            <tr>
                <td>{{$editor->id}}</td>
                <td>{{$editor->name}}</td>
                <td>
                    <form action="{{url("cpanel/editor/$editor->id/delete")}}" method='post'>
                        @csrf
                        @method('delete')
                        <input type='submit' name='deleteEditor' value='delete' />
                    </form>
                </td>
                <td><a href="{{url("cpanel/editor/$editor->id/show")}}">edit</a></td>
            </tr>
        @endforeach
    @else
        <tr>
            <td colspan="4">no editor found</td>
        </tr>
    @endif
</table>
@endSection