@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>show editor info</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/editor/$editor->id/update")}}" method="post">
    @csrf
    @method('patch')
    <label>Editor name</label>
    <input type="text" name="name" value="{{$editor->name}}"/>
    <label>Editor salary</label>
    <input type="text" name="salary" value="{{$editor->salary}}"/>
    <input type="submit" name="updateEditor" value="update editor" />
</form>
@endSection