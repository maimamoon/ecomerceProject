@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>show category info</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/category/$category->id/update")}}" method="post">
        @csrf
        @method('patch')
        <label>Category name</label>
        <input type="text" name="name" value="{{$category->name}}"/>
        <label>Managed By</label>
        <select name="id_manager">
                @if(!$allEditors->isEmpty())
                    @foreach($allEditors as $editor)
                        @if($editor->id == $category->id_manager)
                            <option selected="selected" value="{{$editor->id}}">{{$editor->name}}</a>
                        @else
                            <option value="{{$editor->id}}">{{$editor->name}}</a>
                        @endif
                    @endforeach
                @else
                    <option value="">no editor found</a>
                @endif
        </select>
        <input type="submit" name="updateCategory" value="update category" />
</form>
@endSection