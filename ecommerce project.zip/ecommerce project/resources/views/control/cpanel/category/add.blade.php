@extends('template.cpanel.cpanelmaster')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>Add new category</h3>
@if ($errors->any())
    <p class="message errorMessage">
        {{$errors->first()}}
    </p>
@elseif (session('status'))
    <p class="message successMessage">
        {{ session('status') }}
    </p>
@endif
<form action="{{url("cpanel/category/store")}}" method="post">
        @csrf
        <label>Category name</label>
        <input type="text" name="name" />
        <label>Managed By</label>
        <select name="id_manager">
            @if(!$allEditors->isEmpty())
                @foreach($allEditors as $editor)
                    <option value="{{$editor->id}}">{{$editor->name}}</a>
                @endforeach
            @else
                <option value="">no editor found</a>
            @endif
        </select>
        <input type="submit" name="addCategory" value="add new category" />
</form>
@endSection