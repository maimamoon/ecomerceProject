@extends('template.front.master')
@section('pageTitle', "{$pageTitle}")
@section('content')
<h3>our Product</h3>
<div class="section">
    @if(!$allNews->isEmpty())
        @foreach($allNews as $key=>$news)
            @if(($key+1)%4 == 0)
                <div class=" box pullRight">
                    <div class=" imageBox">
                        <img src="{{asset("assets/upload/$news->main_image")}}" />
                    </div>
                    <h4>
                        <a href="{{url("news/$news->id/show")}}">{{$news->title}}</a>
                    </h4>
                    <p>
                        {{substr($news->content, 0, 75)}} ...
                        <a href="{{url("news/$news->id/show")}}">read more </a>
                    </p>
                    <button class="addCart">
                        Add To Cart
                    </button>
                </div>
            @else
                <div class="box">
                    
                    <div class="imageBox">
                        <img src="{{asset("assets/upload/$news->main_image")}}" />
                    </div>
                    <h4>
                        <a href="{{url("news/$news->id/show")}}">{{$news->title}}</a>
                    </h4>
                    <p>
                        {{substr($news->content, 0, 75)}} ...
                        <a href="{{url("news/$news->id/show")}}">read more </a>
                    </p>
                    <button class="addCart">
                        Add To Cart
                    </button>
                </div>

            @endif
            
        @endforeach
    @else
        <p class="message successMessage">
            no news found
        </p>
    @endif
</div>
@endSection