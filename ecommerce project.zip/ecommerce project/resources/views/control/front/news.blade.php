
@extends('template.front.shop-single')
@section('pageTitle', "{$pageTitle}")
@section('product')

    @if($news)
       <h3>{{$news->title}}</h3>
        <img class="imageNews" src="{{asset("assets/upload/$news->main_image")}}" />
        <p >
                {{$news->content}}
        </p>
    @else
        <p class="message successMessage">
            no news found
        </p>
    @endif
@endSection
