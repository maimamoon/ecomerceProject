@extends('template.front.shop')
@section('pageTitle', "{$pageTitle}")
@section('category')
<h3>Latest News</h3>
<div class="section">
    @if(!$allNews->isEmpty())
        @foreach($allNews as $key=>$news)
            @if(($key+1)%4 == 0)
                <div class="box pullRight">
                    <div class="imageBox">
                        <img src="{{asset("assets/upload/$news->main_image")}}" />
                    </div>
                    <h4>
                        <a href="{{url("news/$news->id/show")}}">{{$news->title}}</a>
                    </h4>
                    <p>
                        {{substr($news->content, 0, 75)}} ...
                        <a href="{{url("news/$news->id/show")}}">read more </a>
                    </p>
                </div>
            @else
                <div class="box">
                    <div class="imageBox">
                        <img src="{{asset("assets/upload/$news->main_image")}}" />
                    </div>
                    <h4>
                        <a href="{{url("news/$news->id/show")}}">{{$news->title}}</a>
                    </h4>
                    <p>
                        {{substr($news->content, 0, 75)}} ...
                        <a href="{{url("news/$news->id/show")}}">read more </a>
                    </p>
                </div>
            @endif
            
        @endforeach
    @else
        <p class="message successMessage">
            no news found
        </p>
    @endif
</div>
@endSection