<div id="navbar">
				<ul>
					<li><a href="{{url("cpanel/editor/create")}}">add editor</a></li>
					<li><a href="{{url("cpanel/editor/all")}}">edit editor</a></li>
					<li><a href="{{url("cpanel/category/create")}}">add category</a></li>
					<li><a href="{{url("cpanel/category/all")}}">edit category</a></li>
					<li><a href="{{url("cpanel/news/create")}}">add product</a></li>
					<li><a href="{{url("cpanel/news/all")}}">edit product</a></li>
				</ul>
			</div>