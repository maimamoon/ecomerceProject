<html>
	<head>
		<title>@yield("pageTitle")</title>
		<link rel="styleSheet" type="text/css" href="{{asset('assets/cpanel/css/reset-min.css')}}" />
		<link rel="styleSheet" type="text/css" href="{{asset('assets/cpanel/css/fonts-min.css')}}" />
		<link rel="styleSheet" type="text/css" href="{{asset('assets/cpanel/css/base.css')}}" />
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<h1>
					<a href="{{url("cpanel/home/index")}}">Cntrole Pege</a>
				</h1>
			</div>