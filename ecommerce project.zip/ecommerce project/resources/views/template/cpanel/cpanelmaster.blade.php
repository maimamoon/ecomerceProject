@include('template.cpanel.header')		
@include('template.cpanel.navbar')		
<div id="content">
	@yield('content')
</div>
@include('template.cpanel.footer')