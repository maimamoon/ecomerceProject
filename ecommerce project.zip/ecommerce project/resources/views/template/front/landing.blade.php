<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="{{asset('assets/front/css/master.css')}}" >
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    
   
   
</head>
<body>
  <!--start landing page-->
  <div class="landingPage" id="landing">
    <div class="overlay"></div>
    <div class="header">
      <div class="logo">Social</div>
    <ul class="links">
      <li><a href="" class="active">Home</a></li>
      <li><a href="" >Product</a></li>
      <li><a href="" >About Us</a></li>
      <li><a href="" >Contact Us</a></li>
    </ul>
    
    </div>
  
    <div class="introduvtion-text" >
      <h1 >our <span>website </span> ecommerce</h1>
      <p>Lorem ipsum dolor sit amet consectetur, amet consectetur,Lorem </p><p>ipsum dolor sit amet  Lorem ipsum dolor sit amet</p>
    </div>
    <button class="button">shop</button>
  </div>
  <!--end landing page-->
  <script src="{{asset('assets/front/js/master.js')}}"></script>
</body>
</html>