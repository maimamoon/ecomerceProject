@extends('template.front.master')
@section('pageTitle', 'my title')
@section('content', 'my content')