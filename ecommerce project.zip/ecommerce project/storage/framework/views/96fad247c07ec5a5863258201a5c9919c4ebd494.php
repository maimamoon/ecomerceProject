<?php $__env->startSection('pageTitle', 'my title'); ?>
<?php $__env->startSection('content', 'my content'); ?>
<?php echo $__env->make('template.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/welcome.blade.php ENDPATH**/ ?>