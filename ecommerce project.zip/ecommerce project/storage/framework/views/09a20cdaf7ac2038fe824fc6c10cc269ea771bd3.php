<div id="footer">
				<p>powerd by our team</p>
			</div>
		</div>
	</body>
</html><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/template/cpanel/footer.blade.php ENDPATH**/ ?>