<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('product'); ?>

    <?php if($news): ?>
       <h3><?php echo e($news->title); ?></h3>
        <img class="imageNews" src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" />
        <p >
                <?php echo e($news->content); ?>

        </p>
    <?php else: ?>
        <p class="message successMessage">
            no news found
        </p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.front.shop-single', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/control/front/news.blade.php ENDPATH**/ ?>