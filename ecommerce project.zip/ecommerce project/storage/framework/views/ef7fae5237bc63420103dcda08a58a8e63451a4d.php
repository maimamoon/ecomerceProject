<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>Latest product</h3>
<div class="section">
    <?php if(!$allNews->isEmpty()): ?>
     <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($key+1)%4 == 0): ?>
                        <div class="col-lg-9">
                            <div class="row">
                        <div class="col-md-4">
                            <div class="card mb-4 product-wap rounded-0">
                                <div class="card rounded-0">
                                    <img class="card-img rounded-0 img-fluid" src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" />
                                    <div class="card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center">
                                        <ul class="list-unstyled">
                                            <li><a class="btn btn-success text-white" href="shop-single.html"><i class="far fa-heart"></i></a></li>
                                            <li><a class="btn btn-success text-white mt-2" href="<?php echo e(url("news/$news->id/show")); ?>"><i class="far fa-eye"></i></a></li>
                                            <li><a class="btn btn-success text-white mt-2" href="shop-single.html"><i class="fas fa-cart-plus"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
            <?php else: ?>      
                    
          
            <div class="col-lg-9">
                <div class="row">
                    
            <div class="col-md-4">
                <div class="card mb-4 product-wap rounded-0">
                    <div class="card rounded-0">
                        <img class="card-img rounded-0 img-fluid" src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" />
                        <div class="card-img-overlay rounded-0 product-overlay d-flex align-items-center justify-content-center">
                            <ul class="list-unstyled">
                                <li><a class="btn btn-success text-white" href="shop-single.html"><i class="far fa-heart"></i></a></li>
                                <li><a class="btn btn-success text-white mt-2" href="<?php echo e(url("news/$news->id/show")); ?>"><i class="far fa-eye"></i></a></li>
                                <li><a class="btn btn-success text-white mt-2" href="shop-single.html"><i class="fas fa-cart-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                
                    
                    <h4>
                        <a href="<?php echo e(url("news/$news->id/show")); ?>"><?php echo e($news->title); ?></a>
                    </h4>
                    <p>
                        <?php echo e(substr($news->content, 0, 75)); ?> ...
                        <a href="<?php echo e(url("news/$news->id/show")); ?>">read more </a>
                    </p>
                </div>
                </div>
               
                
                    </div>
                
            
            </div>
            <?php endif; ?>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p class="message successMessage">
            no news found
        </p>
    
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/control/front/index.blade.php ENDPATH**/ ?>