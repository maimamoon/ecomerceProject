<div id="navbar">
				<ul>
					<li><a href="#">sport</a></li>
					<li><a href="#">media</a></li>
					<li><a href="#">talkshow</a></li>
					<li><a href="#">economy</a></li>
					<li><a href="#">poltical</a></li>
				</ul>
			</div><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/template/front/navbar.blade.php ENDPATH**/ ?>