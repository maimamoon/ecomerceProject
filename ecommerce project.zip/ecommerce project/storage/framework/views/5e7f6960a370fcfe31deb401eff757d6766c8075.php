<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>Statstics</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<table>
    <tr>
        <th>Item</th>
        <th>Value</th>
    </tr>
    <tr>
        <td>Number of editors</td>
        <td><?php echo e($noOfAllEditors); ?></td>
    </tr>
    <tr>
        <td>Number of categories</td>
        <td><?php echo e($noOfAllCategories); ?></td>
    </tr>
    <tr>
        <td>Number of products</td>
        <td><?php echo e($noOfAllNews); ?></td>
    </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/home/index.blade.php ENDPATH**/ ?>