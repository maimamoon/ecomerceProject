<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>show all editors</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<table>
    <tr>
            <th>ID</th>
            <th>name</th>
            <th>delete</th>
            <th>edit</th>
    </tr>
    <?php if(!$allEditors->isEmpty()): ?>
        <?php $__currentLoopData = $allEditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($editor->id); ?></td>
                <td><?php echo e($editor->name); ?></td>
                <td>
                    <form action="<?php echo e(url("cpanel/editor/$editor->id/delete")); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type='submit' name='deleteEditor' value='delete' />
                    </form>
                </td>
                <td><a href="<?php echo e(url("cpanel/editor/$editor->id/show")); ?>">edit</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="4">no editor found</td>
        </tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/editor/all.blade.php ENDPATH**/ ?>