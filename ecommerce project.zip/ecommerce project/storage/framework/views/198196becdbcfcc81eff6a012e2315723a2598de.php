<div id="footer">
				<p>powered by our team</p>
			</div>
		</div>
	</body>
</html><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/template/cpanel/footer.blade.php ENDPATH**/ ?>