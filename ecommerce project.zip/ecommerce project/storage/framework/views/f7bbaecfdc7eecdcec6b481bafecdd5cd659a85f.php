<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>Add new Product</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<form action="<?php echo e(url("cpanel/news/store")); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <label>Product Name</label>
    <input type="text" name="title" />
    <label>News content</label>
    <textarea name="content">
    </textarea>
    <label>written By</label>
    <select name="id_editor">
        <?php if(!$allEditors->isEmpty()): ?>
            <?php $__currentLoopData = $allEditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($editor->id); ?>"><?php echo e($editor->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <option value="">no editor found</a>
        <?php endif; ?>
    </select>
    <label>belong to</label>
    <select name="id_category">
        <?php if(!$allCategories->isEmpty()): ?>
            <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <option value="">no category found</a>
        <?php endif; ?>
    </select>
    <label>main image</label>
    <input type="file" name="main_image" />
    <input type="submit" name="addNews" value="add new product" />
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/news/add.blade.php ENDPATH**/ ?>