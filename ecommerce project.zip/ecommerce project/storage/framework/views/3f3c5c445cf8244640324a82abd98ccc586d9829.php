<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>Add new editor</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<form action="<?php echo e(url("cpanel/editor/store")); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label>Editor name</label>
    <input type="text" name="name" />
    <label>Editor salary</label>
    <input type="text" name="salary" />
    <input type="submit" name="addEditor" value="add new editor" />
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/editor/add.blade.php ENDPATH**/ ?>