<div id="navbar">
				<ul>
					<li><a href="<?php echo e(url("cpanel/editor/create")); ?>">add editor</a></li>
					<li><a href="<?php echo e(url("cpanel/editor/all")); ?>">edit editor</a></li>
					<li><a href="<?php echo e(url("cpanel/category/create")); ?>">add category</a></li>
					<li><a href="<?php echo e(url("cpanel/category/all")); ?>">edit category</a></li>
					<li><a href="<?php echo e(url("cpanel/news/create")); ?>">add product</a></li>
					<li><a href="<?php echo e(url("cpanel/news/all")); ?>">edit product</a></li>
				</ul>
			</div><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/template/cpanel/navbar.blade.php ENDPATH**/ ?>