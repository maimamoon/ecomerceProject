<?php echo $__env->make('template.cpanel.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		
<?php echo $__env->make('template.cpanel.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		
<div id="content">
	<?php echo $__env->yieldContent('content'); ?>
</div>
<?php echo $__env->make('template.cpanel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/template/cpanel/cpanelmaster.blade.php ENDPATH**/ ?>