<div id="footer">
				<p>powered by our team</p>
			</div>
		</div>
	</body>
</html><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/template/cpanel/footer.blade.php ENDPATH**/ ?>