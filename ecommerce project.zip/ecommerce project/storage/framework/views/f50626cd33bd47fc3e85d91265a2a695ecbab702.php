<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/shop.css')); ?>">
    <title>Document</title>
</head>
<body class="">
    <div class="container">
        <header>
        <h1>shopping</h1>
        <div class="icon-cart">
            <svg class="w-[41px] h-[41px] text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.7" d="M5 4h1.5L9 16m0 0h8m-8 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm8 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-8.5-3h9.25L19 7H7.312"/>
            </svg>
            <span>0</span>
        </div>
        </header>
        <?php echo $__env->yieldContent('content'); ?>
               
      
    </div>
    <div class="cartTap">
    <h1>Shopping cart</h1>
    <div class="listCart">
        <div class="item">
            <div class="image">
                <img src="<?php echo e(asset('assets/front/image/01.jpg')); ?>" alt="">
            </div>
            <div class="name">
                name
            </div>
            <div class="quantity">
                <span class="minus"><</span>
                <span>1</span>
                <span class="plus">></span>
            </div>
        </div>
    </div>
    <div class="btn">
        <button class="close">Close</button>
        <button class="checkOut">Check Out</button>
    </div>
    </div>

    
    <script src="<?php echo e(asset('assets/front/js/shop.js')); ?>"></script>
</body>
</html><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/template/front/master.blade.php ENDPATH**/ ?>