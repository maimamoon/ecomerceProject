<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('assets/front/css/shop.css')); ?>">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <header>
        <h1>shopping</h1>
        <div class="icon-cart">
            <svg class="w-[41px] h-[41px] text-gray-800 dark:text-white" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24">
            <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.7" d="M5 4h1.5L9 16m0 0h8m-8 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm8 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4Zm-8.5-3h9.25L19 7H7.312"/>
            </svg>
            <span>0</span>
        </div>
        </header>
        <div class="listProducts">
            <div class="item">
                <img src="<?php echo e(asset('assets/front/image/01.jpg')); ?>" alt="">
                <h2>name product</h2>
                <div class="price">$200</div>
                <button class="addCart">
                    Add To Cart
                </button>
            </div>
        </div>
    </div>

    <script src="js/master.js"></script>
</body>
</html><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/shop.blade.php ENDPATH**/ ?>