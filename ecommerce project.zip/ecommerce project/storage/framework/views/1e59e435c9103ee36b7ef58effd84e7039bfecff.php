<html>
	<head>
		<title><?php echo $__env->yieldContent("pageTitle"); ?></title>
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/cpanel/css/reset-min.css')); ?>" />
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/cpanel/css/fonts-min.css')); ?>" />
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/cpanel/css/base.css')); ?>" />
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<h1>
					<a href="<?php echo e(url("cpanel/home/index")); ?>">Cntrole Pege</a>
				</h1>
			</div><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/template/cpanel/header.blade.php ENDPATH**/ ?>