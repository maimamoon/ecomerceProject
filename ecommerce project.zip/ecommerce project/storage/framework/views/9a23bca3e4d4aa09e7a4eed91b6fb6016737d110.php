<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>show category info</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<form action="<?php echo e(url("cpanel/category/$category->id/update")); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <label>Category name</label>
        <input type="text" name="name" value="<?php echo e($category->name); ?>"/>
        <label>Managed By</label>
        <select name="id_manager">
                <?php if(!$allEditors->isEmpty()): ?>
                    <?php $__currentLoopData = $allEditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($editor->id == $category->id_manager): ?>
                            <option selected="selected" value="<?php echo e($editor->id); ?>"><?php echo e($editor->name); ?></a>
                        <?php else: ?>
                            <option value="<?php echo e($editor->id); ?>"><?php echo e($editor->name); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <option value="">no editor found</a>
                <?php endif; ?>
        </select>
        <input type="submit" name="updateCategory" value="update category" />
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/category/edit.blade.php ENDPATH**/ ?>