<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>show news info</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<form action="<?php echo e(url("cpanel/news/$news->id/update")); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <label>News title</label>
    <input type="text" name="title" value="<?php echo e($news->title); ?>"/>
    <label>News content</label>
    <textarea name="content">
        <?php echo e($news->content); ?>

    </textarea>
    <label>written By</label>
    <select name="id_editor">
        <?php if(!$allEditors->isEmpty()): ?>
            <?php $__currentLoopData = $allEditors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($editor->id == $news->id_editor): ?>
                    <option selected="selected" value="<?php echo e($editor->id); ?>"><?php echo e($editor->name); ?></a>
                <?php else: ?>
                    <option value="<?php echo e($editor->id); ?>"><?php echo e($editor->name); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <option value="">no editor found</a>
        <?php endif; ?>
    </select>
    <label>belong to</label>
    <select name="id_category">
        <?php if(!$allCategories->isEmpty()): ?>
            <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == $news->id_category): ?>
                    <option selected="selected" value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
                <?php else: ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <option value="">no category found</a>
        <?php endif; ?>
    </select>
    <label>main image</label>
    <img src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" width="90" height="90" />
    <input type="file" name="main_image" />
    <input type="submit" name="updateNews" value="update news" />
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/cpanel/news/edit.blade.php ENDPATH**/ ?>