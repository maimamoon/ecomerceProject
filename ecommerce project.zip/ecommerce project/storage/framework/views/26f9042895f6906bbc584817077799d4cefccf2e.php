<html>
	<head>
		<title><?php echo $__env->yieldContent("pageTitle"); ?></title>
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/front/css/reset-min.css')); ?>" />
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/front/css/fonts-min.css')); ?>" />
		<link rel="styleSheet" type="text/css" href="<?php echo e(asset('assets/front/css/base.css')); ?>" />
	</head>
	<body>
		<div id="wrapper">
			<div id="header">
				<h1>
					<a href="#">NEWSPAPER</a>
				</h1>
			</div><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/template/front/header.blade.php ENDPATH**/ ?>