<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>show editor info</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<form action="<?php echo e(url("cpanel/editor/$editor->id/update")); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('patch'); ?>
    <label>Editor name</label>
    <input type="text" name="name" value="<?php echo e($editor->name); ?>"/>
    <label>Editor salary</label>
    <input type="text" name="salary" value="<?php echo e($editor->salary); ?>"/>
    <input type="submit" name="updateEditor" value="update editor" />
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/control/cpanel/editor/edit.blade.php ENDPATH**/ ?>