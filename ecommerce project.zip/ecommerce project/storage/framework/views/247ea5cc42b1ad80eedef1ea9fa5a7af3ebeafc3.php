<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>our Product</h3>
<div class="section">
    <?php if(!$allNews->isEmpty()): ?>
        <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(($key+1)%4 == 0): ?>
                <div class=" box pullRight">
                    <div class=" imageBox">
                        <img src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" />
                    </div>
                    <h4>
                        <a href="<?php echo e(url("news/$news->id/show")); ?>"><?php echo e($news->title); ?></a>
                    </h4>
                    <p>
                        <?php echo e(substr($news->content, 0, 75)); ?> ...
                        <a href="<?php echo e(url("news/$news->id/show")); ?>">read more </a>
                    </p>
                    <button class="addCart">
                        Add To Cart
                    </button>
                </div>
            <?php else: ?>
                <div class="box">
                    
                    <div class="imageBox">
                        <img src="<?php echo e(asset("assets/upload/$news->main_image")); ?>" />
                    </div>
                    <h4>
                        <a href="<?php echo e(url("news/$news->id/show")); ?>"><?php echo e($news->title); ?></a>
                    </h4>
                    <p>
                        <?php echo e(substr($news->content, 0, 75)); ?> ...
                        <a href="<?php echo e(url("news/$news->id/show")); ?>">read more </a>
                    </p>
                    <button class="addCart">
                        Add To Cart
                    </button>
                </div>

            <?php endif; ?>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p class="message successMessage">
            no news found
        </p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Desktop/ecommerce project/resources/views/control/front/index.blade.php ENDPATH**/ ?>