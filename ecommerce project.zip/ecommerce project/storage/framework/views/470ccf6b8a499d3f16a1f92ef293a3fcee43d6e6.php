<div id="navbar">
				<ul>
					<li><a href="#">add editor</a></li>
					<li><a href="#">edit editor</a></li>
					<li><a href="#">add category</a></li>
					<li><a href="#">edit category</a></li>
					<li><a href="#">add news</a></li>
					<li><a href="#">edit news</a></li>
				</ul>
			</div><?php /**PATH C:\Users\CLS\Desktop\Eng Ahmed Fathi\session34\pro1\resources\views/template/cpanel/navbar.blade.php ENDPATH**/ ?>