<?php $__env->startSection('pageTitle', "{$pageTitle}"); ?>
<?php $__env->startSection('content'); ?>
<h3>show all news</h3>
<?php if($errors->any()): ?>
    <p class="message errorMessage">
        <?php echo e($errors->first()); ?>

    </p>
<?php elseif(session('status')): ?>
    <p class="message successMessage">
        <?php echo e(session('status')); ?>

    </p>
<?php endif; ?>
<table>
    <tr>
        <th>ID</th>
        <th>title</th>
        <th>delete</th>
        <th>edit</th>
    </tr>
    <?php if(!$allNews->isEmpty()): ?>
        <?php $__currentLoopData = $allNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($news->id); ?></td>
                <td><?php echo e($news->title); ?></td>
                <td>
                    <form action="<?php echo e(url("cpanel/news/$news->id/delete")); ?>" method='post'>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type='submit' name='deleteNews' value='delete' />
                    </form>
                </td>
                <td><a href="<?php echo e(url("cpanel/news/$news->id/show")); ?>">edit</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="4">no category found</td>
        </tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.cpanel.cpanelmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/maimamoonmohamed/Downloads/session34/pro1/resources/views/control/cpanel/news/all.blade.php ENDPATH**/ ?>