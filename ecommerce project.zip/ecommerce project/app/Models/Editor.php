<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Editor extends Model
{
    use HasFactory;
	protected $table = 'editor';
	protected $primaryKey  = 'id';
	public function categories()
	{
		return $this->hasMany(Category::class, 'id_manager', 'id');
	}
	public function News()
	{
		return $this->hasMany(News::class, 'id_editor', 'id');
	}
}

