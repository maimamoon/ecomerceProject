<?php

namespace App\Http\Controllers\front;
use App\Models\News;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function index()
    {
        // set page settings 
        $pageTitle = "home page";
        $allNews = News::orderBy('id', 'DESC')->get();
        // load view and pass data to my view 
        return view("control.front.index",[
            "pageTitle"=>$pageTitle,
            "allNews"=>$allNews
        ]);
    }
    public function category($id)
    {
        // set page settings 
        $pageTitle = "category page";
        $allNews = News::where('id_category', 0)->orderBy('id', 'DESC')->get();
        // load view and pass data to my view 
        return view("control.front.category",[
            "pageTitle"=>$pageTitle,
            "allNews"=>$allNews
        ]);
    }
    public function news($id)
    {
        // set page settings 
        $pageTitle = "news page";
        $news = News::find($id);
        // load view and pass data to my view 
        return view("control.front.news",[
            "pageTitle"=>$pageTitle,
            "news"=>$news
        ]);
    }
}

