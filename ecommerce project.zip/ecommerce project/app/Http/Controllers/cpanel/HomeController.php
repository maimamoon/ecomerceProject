<?php

namespace App\Http\Controllers\cpanel;
use App\Models\Editor;
use App\Models\Category;
use App\Models\News;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        // set page settings 
        $pageTitle = "dashboard";
        // get all NO OF editors 
        $noOfAllEditors = Editor::count();
        // get all NO OF categories 
        $noOfAllCategories = Category::count();
        // get all NO OF News 
        $noOfAllNews = News::count();
        // load view and pass data to my view 
        return view("control.cpanel.home.index", [
            "pageTitle"=>$pageTitle,
            "noOfAllEditors"=>$noOfAllEditors,
            'noOfAllCategories'=>$noOfAllCategories,
            'noOfAllNews'=>$noOfAllNews,
        ]);
    }
}

