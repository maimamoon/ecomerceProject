<?php

namespace App\Http\Controllers\cpanel;
use App\Models\Editor;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EditorController extends Controller
{
    public function create()
    {
        // set page settings 
        $pageTitle = "add new editor";
        // load view and pass data to my view 
        return view("control.cpanel.editor.add", ["pageTitle"=>$pageTitle]);
    }
    public function store(Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'name' => 'required',
            'salary' => 'required|numeric',
        ]);
        // create object
        $editor = new Editor();
        // set data to my object
        $editor->name = $request->name;
        $editor->salary = $request->salary;
        // save data into object 
        if($editor->save()){
            return back()->with("status", "success");
        }else{
            return back()->withErrors(['status' => 'fail']);
        }
    }
    public function all()
    {
        // set page settings 
        $pageTitle = "show all editors";
        // get all editors 
        $allEditors = Editor::all();
        //load view and pass data my view 
        return view("control.cpanel.editor.all",[
            "pageTitle"=>$pageTitle,
            "allEditors"=>$allEditors
        ]);
    }
    public function show($id)
    {
        // get editor info 
        $editor = Editor::find($id);
        if($editor){
            // set page settings 
            $pageTitle = "show editor info";
            // load view and pass data to my view 
            return view("control.cpanel.editor.edit", [
                "pageTitle"=>$pageTitle,
                "editor"=>$editor
            ]);
        }else{
            return back()->withErrors(['status' => 'no editor found']);
        }
    }
    public function update($id, Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'name' => 'required',
            'salary' => 'required|numeric',
        ]);
        // get editor info
        $editor = Editor::find($id);
        // set data to my object
        $editor->name = $request->name;
        $editor->salary = $request->salary;
        // save data into object 
        if($editor->save()){
            return back()->with("status", "success");
        }else{
            return back()->withErrors(['status' => 'fail']);
        }
    }
    public function delete($id)
    {
        // get editor info 
        $editor = Editor::find($id);
        if($editor){
            if($editor->delete()){
                return back()->with("status", "success");
            }else{
                return back()->withErrors(['status' => 'fail']);
            }
        }else{
            return back()->withErrors(['status' => 'no editor found']);
        }
            
    }
}
