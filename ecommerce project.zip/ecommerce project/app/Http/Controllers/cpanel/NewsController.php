<?php

namespace App\Http\Controllers\cpanel;
use App\Models\Editor;
use App\Models\Category;
use App\Models\News;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class NewsController extends Controller
{
    public function create()
    {
        // set page settings 
        $pageTitle = "add new news";
        // get all editors 
        $allEditors = Editor::all();
        // get all categories 
        $allCategories = Category::all();
        // load view and pass data to my view 
        return view("control.cpanel.news.add", [
            "pageTitle"=>$pageTitle,
            "allEditors"=>$allEditors,
            'allCategories'=>$allCategories
        ]);
    }
    public function store(Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'title' => 'required',
            'content' => 'required',
            'id_editor' => 'required|numeric',
            'id_category' => 'required|numeric',
            'main_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        // rename image
        $imageName = time().'.'.$request->main_image->extension();
        // move image into upload path
        if($request->main_image->move(public_path('assets/upload'), $imageName)){
            // create object
            $news = new News();
            // set data to my object
            $news->title = $request->title;
            $news->content = $request->content;
            $news->id_editor = $request->id_editor;
            $news->id_category = $request->id_category;
            $news->main_image = $imageName;
            // save data into object 
            if($news->save()){
                return back()->with("status", "success");
            }else{
                return back()->withErrors(['status' => 'fail']);
            }
        }else{
            return back()->withErrors(['status' => 'upload another image']);
        }
        
    }
    public function all()
    {
        // set page settings 
        $pageTitle = "show all news";
        // get all News 
        $allNews = News::all();
        //load view and pass data my view 
        return view("control.cpanel.news.all",[
            "pageTitle"=>$pageTitle,
            "allNews"=>$allNews
        ]);
    }
    public function show($id)
    {
        // set page settings 
        $pageTitle = "add new news";
        // get all editors 
        $allEditors = Editor::all();
        // get all categories 
        $allCategories = Category::all();
        // get news info 
        $news = News::find($id);
        // load view and pass data to my view 
        return view("control.cpanel.news.edit", [
            "pageTitle"=>$pageTitle,
            "allEditors"=>$allEditors,
            'allCategories'=>$allCategories,
            'news'=>$news
        ]);
    }
    public function update($id, Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'title' => 'required',
            'content' => 'required',
            'id_editor' => 'required|numeric',
            'id_category' => 'required|numeric',
            'main_image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);
        // rename image
        $imageName = time().'.'.$request->main_image->extension();
        // move image into upload path
        if($request->main_image->move(public_path('assets/upload'), $imageName)){
            // get news by id
            $news = News::find($id);
            // set data to my object
            $news->title = $request->title;
            $news->content = $request->content;
            $news->id_editor = $request->id_editor;
            $news->id_category = $request->id_category;
            $news->main_image = $imageName;
            // save data into object 
            if($news->save()){
                return back()->with("status", "success");
            }else{
                return back()->withErrors(['status' => 'fail']);
            }
        }else{
            return back()->withErrors(['status' => 'upload another image']);
        }
    }
    public function delete($id)
    {
        // get news info 
        $news = News::find($id);
        if($news){
            if($news->delete()){
                return back()->with("status", "success");
            }else{
                return back()->withErrors(['status' => 'fail']);
            }
        }else{
            return back()->withErrors(['status' => 'no news found']);
        }
    }
}
