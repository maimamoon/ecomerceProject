<?php

namespace App\Http\Controllers\cpanel;
use App\Models\Editor;
use App\Models\Category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function create()
    {
        // set page settings 
        $pageTitle = "add new category";
        // get all editors 
        $allEditors = Editor::all();
        // load view and pass data to my view 
        return view("control.cpanel.category.add", [
            "pageTitle"=>$pageTitle,
            "allEditors"=>$allEditors
        ]);
        
    }
    public function store(Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'name' => 'required',
            'id_manager' => 'required|numeric',
        ]);
        // create object
        $category = new Category();
        // set data to my object
        $category->name = $request->name;
        $category->id_manager = $request->id_manager;
        // save data into object 
        if($category->save()){
            return back()->with("status", "success");
        }else{
            return back()->withErrors(['status' => 'fail']);
        }
    }
    public function all()
    {
        // set page settings 
        $pageTitle = "show all categories";
        // get all categories 
        $allCategories = Category::all();
        //load view and pass data my view 
        return view("control.cpanel.category.all",[
            "pageTitle"=>$pageTitle,
            "allCategories"=>$allCategories
        ]);
    }
    public function show($id)
    {
        // get category info 
        $category = Category::find($id);
        if($category){
            // set page settings 
            $pageTitle = "show category info";
            // get all editors 
            $allEditors = Editor::all();
            // load view and pass data to my view 
            return view("control.cpanel.category.edit", [
                "pageTitle"=>$pageTitle,
                "category"=>$category,
                "allEditors"=>$allEditors
            ]);
        }else{
            return back()->withErrors(['status' => 'no editor found']);
        }
    }
    public function update($id, Request $request)
    {
        // check data valid or not 
        $validated = $request->validate([
            'name' => 'required',
            'id_manager' => 'required|numeric',
        ]);
        // get category
        $category = Category::find($id);
        // set data to my object
        $category->name = $request->name;
        $category->id_manager = $request->id_manager;
        // save data into object 
        if($category->save()){
            return back()->with("status", "success");
        }else{
            return back()->withErrors(['status' => 'fail']);
        }
    }
    public function delete($id)
    {
        // get category info 
        $category = Category::find($id);
        if($category){
            if($category->delete()){
                return back()->with("status", "success");
            }else{
                return back()->withErrors(['status' => 'fail']);
            }
        }else{
            return back()->withErrors(['status' => 'no category found']);
        }
    }
}
