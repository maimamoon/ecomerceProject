<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class News extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       Schema::create('news', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('content');
			$table->bigInteger('id_editor')->unsigned()->index()->nullable();
			$table->bigInteger('id_category')->unsigned()->index()->nullable();
			$table->string('main_image');
			$table->foreign('id_editor')->references('id')->on('editor')->onDelete('cascade');
			$table->foreign('id_category')->references('id')->on('category')->onDelete('cascade');
            $table->timestamps(); // created_at- updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
